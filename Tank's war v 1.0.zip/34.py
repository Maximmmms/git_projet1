import os
import sys
import pygame
from random import randrange


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == 1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def load_level(filename):
    filename = "data/" + filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map))
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


def generate_level(level):
    new_player, new_enemy = None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Grass(x, y)
            elif level[y][x] == '#':
                Wall(x, y)
            elif level[y][x] == '@':
                Grass(x, y)
                new_player = Player(x, y)
            elif level[y][x] == '*':
                Grass(x, y)
                new_enemy = Enemy(x, y)
    return new_player, new_enemy


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["БИТВА ТАНКОВ", "",
                  "ПРАВИЛА:", "",
                  "1) Чтобы двигаться, нажмите на любую из четырех клавиш - стрелок.",
                  "2) Чтобы стрелять, нажмите на клавишу Пробел.",
                  "3) Для победы нужно уничтожить вражеский танк.",
                  "4) Чтобы редактировать карту, откройте файл map.txt.",
                  "5) '.' - пустое место, '#' - стена, '@' - ваш танк, '*' - вражеский танк.",
                  "6) В файле map.txt, должна быть хотябы одна строка с 20 символами и столбец с 12.",
                  "7) На карте может быть только один враг и только один ваш танк.",
                  "8) Чтобы начать игру, нажмите любую клавишу."]

    fon = pygame.transform.scale(load_image('fire.jpeg'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 100
    for line in intro_text:
        if line == 'БИТВА ТАНКОВ':
            string_rendered = font.render(line, 1, pygame.Color('red'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.x = 420
        elif line == 'ПРАВИЛА:':
            string_rendered = font.render(line, 1, pygame.Color('yellow'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.x = 450
        else:
            string_rendered = font.render(line, 1, pygame.Color('white'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.x = 10
        intro_rect.top = text_coord
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return True
        pygame.display.flip()


class Board:
    CELL_SIZE = 50

    def __init__(self, width, height, screen):
        self.screen = screen
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def get_click(self, mouse_pos):
        return self.get_cell(mouse_pos)

    def get_cell(self, mouse_pos):
        a = (list(mouse_pos)[0] - self.left) // self.cell_size
        b = (list(mouse_pos)[1] - self.top) // self.cell_size
        if a > self.width or b > self.height:
            return None
        else:
            return (a, b)

    def on_click(self, cell_coords):
        pass

    def render(self):
        for i in range(len(self.board)):
            for j in range(len(self.board[i])):
                pygame.draw.rect(self.screen, (255, 255, 255),
                                 (self.top + j * self.cell_size,
                                  self.left + i * self.cell_size,
                                  self.cell_size, self.cell_size), 1)


class Player(pygame.sprite.Sprite):

    def __init__(self, x, y, direction='up'):
        super().__init__(player_group, players)
        self.image = None
        self.x, self.y = x, y
        self.direction = direction
        self.patron = Patron(self)
        self.move()

    def move(self):
        if self.direction == 'up':
            self.image = pygame.transform.scale(load_image('tank1.png'), (50, 50))
        elif self.direction == 'down':
            self.image = pygame.transform.scale(load_image('tank2.png'), (50, 50))
        elif self.direction == 'left':
            self.image = pygame.transform.scale(load_image('tank3.png'), (50, 50))
        else:
            self.image = pygame.transform.scale(load_image('tank4.png'), (50, 50))
        self.rect = self.image.get_rect().move(tile_width * self.x, tile_height * self.y)

    def get_coords(self):
        return self.x, self.y

    def fire(self):
        self.patron.x, self.patron.y = self.x * Board.CELL_SIZE, self.y * Board.CELL_SIZE
        self.patron.direction = self.direction
        if self.direction == 'up':
            patron_image = load_image('patron1.png', 1)
        elif self.direction == 'down':
            patron_image = load_image('patron2.png', 1)
        elif self.direction == 'left':
            patron_image = load_image('patron3.png', 1)
        else:
            patron_image = load_image('patron4.png', 1)
        self.patron.image = pygame.transform.scale(patron_image, (Board.CELL_SIZE, Board.CELL_SIZE))
        self.patron.move()


class Wall(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.image = wall_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)
        self.add(walls)


class Patron(pygame.sprite.Sprite):
    def __init__(self, player):
        super().__init__(player_group, patrons)
        self.image = pygame.transform.scale(load_image('patron1.png', 1),
                                            (Board.CELL_SIZE, Board.CELL_SIZE))
        self.x, self.y, self.direction = -999999, -999999, 'none'
        self.player = player
        self.rect = self.image.get_rect().move(self.x, self.y)

    def check(self):
        if pygame.sprite.spritecollideany(self, walls) or \
                pygame.sprite.spritecollideany(self, enemies):
            self.x, self.y, self.direction = -999999, -999999, 'none'
            return False
        else:
            return True

    def move(self):
        self.check()
        if self.direction == 'up':
            self.y -= 1
        elif self.direction == 'down':
            self.y += 1
        elif self.direction == 'left':
            self.x -= 1
        elif self.direction == 'right':
            self.x += 1
        self.rect = self.image.get_rect().move(self.x, self.y)


class Grass(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.image = grass_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__(enemies)
        self.image = pygame.transform.scale(load_image('enemy1.png', 1),
                                            (Board.CELL_SIZE, Board.CELL_SIZE))
        self.x, self.y, self.direction = x * Board.CELL_SIZE, y * Board.CELL_SIZE, 1
        self.rect = self.image.get_rect().move(self.x, self.y)

    def check(self):
        if pygame.sprite.spritecollideany(self, walls) or \
                pygame.sprite.spritecollideany(self, players):
            return False
        else:
            return True

    def boom(self):
        if pygame.sprite.spritecollideany(self, patrons):
            return True
        else:
            return False

    def kaaaaboooooom(self):
        self.x, self.y, self.direction = -999999, -999999, 'none'

    def move(self):
        if self.direction == 1 and self.check():
            self.image = pygame.transform.scale(load_image('enemy1.png', 1),
                                                (Board.CELL_SIZE, Board.CELL_SIZE))
            self.y -= 1
        elif self.direction == 1 and not self.check():
            self.direction = randrange(1, 5)
            self.y += 1
            self.rect = self.image.get_rect().move(self.x, self.y)
        if self.direction == 2 and self.check():
            self.image = pygame.transform.scale(load_image('enemy2.png', 1),
                                                (Board.CELL_SIZE, Board.CELL_SIZE))
            self.y += 1
        elif self.direction == 2 and not self.check():
            self.direction = randrange(1, 5)
            self.y -= 1
            self.rect = self.image.get_rect().move(self.x, self.y)
        if self.direction == 3 and self.check():
            self.image = pygame.transform.scale(load_image('enemy3.png', 1),
                                                (Board.CELL_SIZE, Board.CELL_SIZE))
            self.x -= 1
        elif self.direction == 3 and not self.check():
            self.direction = randrange(1, 5)
            self.x += 1
            self.rect = self.image.get_rect().move(self.x, self.y)
        if self.direction == 4 and self.check():
            self.image = pygame.transform.scale(load_image('enemy4.png', 1),
                                                (Board.CELL_SIZE, Board.CELL_SIZE))
            self.x += 1
        elif self.direction == 4 and not self.check():
            self.direction = randrange(1, 5)
            self.x -= 1
            self.rect = self.image.get_rect().move(self.x, self.y)
        self.rect = self.image.get_rect().move(self.x, self.y)


if __name__ == '__main__':
    pygame.init()
    size = width, height = 1000, 600
    screen = pygame.display.set_mode(size)
    screen.fill((0, 0, 0))
    board = Board(20, 12, screen)
    board.set_view(0, 0, 50)
    wall = load_image('wall.png')
    wall_image = pygame.transform.scale(wall, (50, 50))
    grass = load_image('grass.png')
    grass_image = pygame.transform.scale(grass, (50, 50))
    tile_width = tile_height = 50
    all_sprites = pygame.sprite.Group()
    walls = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    patrons = pygame.sprite.Group()
    tiles_group = pygame.sprite.Group()
    player_group = pygame.sprite.Group()
    players = pygame.sprite.Group()
    sprite = pygame.sprite.Sprite()
    level = load_level('map.txt')
    player, enemy = generate_level(level)
    if start_screen():
        running = True
    while running:
        screen.fill((0, 0, 0))
        board.render()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                x = player.x
                y = player.y
                if event.key == pygame.K_UP:
                    if level[y - 1][x] == '.' or level[y - 1][x] == '@' or level[y - 1][x] == '*':
                        player.y -= 1
                        player.direction = 'up'
                        player.move()
                if event.key == pygame.K_DOWN:
                    if level[y + 1][x] == '.' or level[y + 1][x] == '@' or level[y + 1][x] == '*':
                        player.y += 1
                        player.direction = 'down'
                        player.move()
                if event.key == pygame.K_LEFT:
                    if level[y][x - 1] == '.' or level[y][x - 1] == '@' or level[y][x - 1] == '*':
                        player.x -= 1
                        player.direction = 'left'
                        player.move()
                if event.key == pygame.K_RIGHT:
                    if level[y][x + 1] == '.' or level[y][x + 1] == '@' or level[y][x + 1] == '*':
                        player.x += 1
                        player.direction = 'right'
                        player.move()
                if event.key == pygame.K_SPACE:
                    player.fire()
        if player.patron is not None:
            player.patron.move()
        if not enemy.boom():
            enemy.move()
        else:
            enemy.image = pygame.transform.scale(load_image('boom.jpeg', 1),
                                                 (Board.CELL_SIZE, Board.CELL_SIZE))
            enemy.kaaaaboooooom()
        all_sprites.draw(screen)
        player_group.draw(screen)
        enemies.draw(screen)
        pygame.display.flip()
    pygame.quit()
